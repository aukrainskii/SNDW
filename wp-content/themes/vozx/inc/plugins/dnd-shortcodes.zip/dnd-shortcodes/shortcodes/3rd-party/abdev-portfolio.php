<?php 


/**
	abdev-portfolio plugin support
**/
if( in_array('abdev-portfolio/abdev-portfolio.php', get_option('active_plugins')) ){ //first check if plugin is installed
	$ABdevDND_shortcodes['portfolio'] = array(
		'third_party' => 1, 
		'attributes' => array(
			'category' => array(
				'description' => __('Portfolio Category', 'dnd-shortcodes'),
				'info' => __('Show only items from specific category, displays all categories if not specified (category slug string)', 'dnd-shortcodes'),
			),
			'style' => array(
				'default' => '1',
				'type' => 'select',
				'values' => array( 
					'1' => '3 Column Fullwidth',
					'2' => '4 Column Fullwidth',
					'3' => '5 Column Fullwidth',
					'4' => '3 Column Boxed',
					'5' => '4 Column Boxed',
				),
				'description' => __('Style', 'dnd-shortcodes'),
			),
			'count' => array(
				'description' => __('Count', 'dnd-shortcodes'),
				'info' => __('Number of portfolio items to be shown', 'dnd-shortcodes'),
				'default' => 8,
			),
			'link_text' => array(
				'description' => __('More Link Text', 'dnd-shortcodes'),
				'info' => __('Enter text to be displayed below items as a link to complete portfolio', 'dnd-shortcodes'),
			),
			'link_url' => array(
				'description' => __('More Link URL', 'dnd-shortcodes'),
				'info' => __('Enter URL for link to complete portfolio', 'dnd-shortcodes'),
			),
			'carousel' => array(
				'description' => __('Carousel', 'dnd-shortcodes'),
				'type' => 'checkbox',
				'default' => '0',
				'info' => __('Check this if you want the carousel enabled. Works with 3 and 4 Column Fullwidth style.', 'dnd-shortcodes'),
			),
		),
		'description' => __('Portfolio', 'dnd-shortcodes'),
	);
}
